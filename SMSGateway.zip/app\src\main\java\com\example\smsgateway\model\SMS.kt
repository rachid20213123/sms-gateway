package com.example.smsgateway.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sms")
data class SMS(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val phoneNumber: String,
    val message: String,
    val status: String,
    val timestamp: Long
)
