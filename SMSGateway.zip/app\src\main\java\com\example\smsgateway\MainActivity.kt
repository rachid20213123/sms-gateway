package com.example.smsgateway

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.smsgateway.databinding.ActivityMainBinding
import com.example.smsgateway.db.SMSDatabase
import com.example.smsgateway.service.SMSService
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var smsService: SMSService
    private lateinit var db: SMSDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = SMSDatabase.getDatabase(this)
        smsService = SMSService(this)

        checkPermissions()
        setupUI()
        startSMSService()
    }

    private fun setupUI() {
        binding.btnSend.setOnClickListener {
            val phoneNumber = binding.etPhoneNumber.text.toString()
            val message = binding.etMessage.text.toString()

            if (phoneNumber.isNotEmpty() && message.isNotEmpty()) {
                lifecycleScope.launch {
                    try {
                        smsService.sendSMS(phoneNumber, message)
                        Toast.makeText(this@MainActivity, "SMS envoyé avec succès", Toast.LENGTH_SHORT).show()
                        loadSMSHistory()
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Erreur: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show()
            }
        }

        // Charger l'historique initial
        loadSMSHistory()
    }

    private fun loadSMSHistory() {
        lifecycleScope.launch {
            val history = db.smsDao().getAllSMS()
            val historyText = history.joinToString("\n") { sms ->
                "${sms.phoneNumber} - ${sms.message} (${sms.status})"
            }
            binding.tvHistory.text = historyText
        }
    }

    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.INTERNET
        )

        val permissionsToRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest, PERMISSIONS_REQUEST_CODE)
        }
    }

    private fun startSMSService() {
        SMSService.startService(this)
    }

    companion object {
        private const val PERMISSIONS_REQUEST_CODE = 123
    }
}
