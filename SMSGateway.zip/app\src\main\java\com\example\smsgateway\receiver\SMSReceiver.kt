package com.example.smsgateway.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.example.smsgateway.db.SMSDatabase
import com.example.smsgateway.model.SMS
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SMSReceiver : BroadcastReceiver() {
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            
            messages?.forEach { smsMessage ->
                val phoneNumber = smsMessage.originatingAddress ?: "Unknown"
                val messageBody = smsMessage.messageBody

                coroutineScope.launch {
                    val db = SMSDatabase.getDatabase(context)
                    val sms = SMS(
                        phoneNumber = phoneNumber,
                        message = messageBody,
                        status = "RECEIVED",
                        timestamp = System.currentTimeMillis()
                    )
                    db.smsDao().insert(sms)
                }
            }
        }
    }
}
