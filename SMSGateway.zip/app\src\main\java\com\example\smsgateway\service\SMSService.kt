package com.example.smsgateway.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.telephony.SmsManager
import com.example.smsgateway.db.SMSDatabase
import com.example.smsgateway.model.SMS
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class SMSService(private val context: Context) {
    private val db = SMSDatabase.getDatabase(context)
    private val smsManager: SmsManager = context.getSystemService(SmsManager::class.java)
    private val serviceScope = CoroutineScope(Dispatchers.IO)

    suspend fun sendSMS(phoneNumber: String, message: String) {
        try {
            smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null
            )

            // Sauvegarder dans la base de données
            val sms = SMS(
                phoneNumber = phoneNumber,
                message = message,
                status = "SENT",
                timestamp = System.currentTimeMillis()
            )
            db.smsDao().insert(sms)
        } catch (e: Exception) {
            val sms = SMS(
                phoneNumber = phoneNumber,
                message = message,
                status = "FAILED: ${e.message}",
                timestamp = System.currentTimeMillis()
            )
            db.smsDao().insert(sms)
            throw e
        }
    }

    companion object {
        fun startService(context: Context) {
            val intent = Intent(context, SMSService::class.java)
            context.startService(intent)
        }
    }

    class SMSServiceImpl : Service() {
        override fun onBind(intent: Intent?): IBinder? = null

        override fun onCreate() {
            super.onCreate()
            startServer()
        }

        private fun startServer() {
            serviceScope.launch {
                try {
                    // Démarrer le serveur HTTP ici si nécessaire
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}
