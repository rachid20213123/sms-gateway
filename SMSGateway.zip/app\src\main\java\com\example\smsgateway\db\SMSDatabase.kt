package com.example.smsgateway.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.smsgateway.model.SMS

@Database(entities = [SMS::class], version = 1)
abstract class SMSDatabase : RoomDatabase() {
    abstract fun smsDao(): SMSDao

    companion object {
        @Volatile
        private var INSTANCE: SMSDatabase? = null

        fun getDatabase(context: Context): SMSDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SMSDatabase::class.java,
                    "sms_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
