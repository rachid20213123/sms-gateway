package com.example.smsgateway.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.smsgateway.model.SMS

@Dao
interface SMSDao {
    @Insert
    suspend fun insert(sms: SMS)

    @Query("SELECT * FROM sms ORDER BY timestamp DESC")
    suspend fun getAllSMS(): List<SMS>

    @Query("DELETE FROM sms")
    suspend fun deleteAll()
}
